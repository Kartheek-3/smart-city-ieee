"""
Lambda Function: blockchain-audit
Trigger: API Gateway POST /audit/log
Action:  Create a tamper-proof blockchain hash chain entry in AuditLogs table
"""
import boto3
import json
import hashlib
import uuid
from datetime import datetime, timezone
from decimal import Decimal

dynamo      = boto3.resource('dynamodb')
audit_table = dynamo.Table('SmartCity-AuditLogs')


def create_hash(entity_type, entity_id, data_str, previous_hash):
    content = f"{entity_type}:{entity_id}:{data_str}:{previous_hash}"
    return hashlib.sha256(content.encode()).hexdigest()


def get_last_hash(entity_type):
    try:
        response = audit_table.query(
            IndexName='entityType-index',
            KeyConditionExpression='entityType = :et',
            ExpressionAttributeValues={':et': entity_type},
            ScanIndexForward=False,
            Limit=1,
        )
        items = response.get('Items', [])
        return items[0]['blockchainHash'] if items else '0' * 64
    except Exception:
        return '0' * 64


def handler(event, context):
    try:
        body        = json.loads(event.get('body', '{}'))
        entity_type = body.get('entityType', 'UNKNOWN')
        entity_id   = body.get('entityId', str(uuid.uuid4()))
        data        = body.get('data', {})
        action      = body.get('action', 'created')
        performed_by = body.get('performedBy', 'SYSTEM')

        data_str      = json.dumps(data, sort_keys=True)
        previous_hash = get_last_hash(entity_type)
        block_hash    = create_hash(entity_type, entity_id, data_str, previous_hash)
        tx_id         = hashlib.sha256(f"{entity_id}:{block_hash}".encode()).hexdigest()[:16]
        timestamp     = datetime.now(timezone.utc).isoformat()
        log_id        = str(uuid.uuid4())

        log_entry = {
            'logId':          log_id,
            'timestamp':      timestamp,
            'entityType':     entity_type,
            'entityId':       entity_id,
            'action':         action,
            'performedBy':    performed_by,
            'data':           data_str,
            'blockchainHash': block_hash,
            'previousHash':   previous_hash,
            'transactionId':  tx_id,
        }

        audit_table.put_item(Item=log_entry)

        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'logId':          log_id,
                'blockchainHash': block_hash,
                'transactionId':  tx_id,
                'timestamp':      timestamp,
            }),
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)}),
        }
